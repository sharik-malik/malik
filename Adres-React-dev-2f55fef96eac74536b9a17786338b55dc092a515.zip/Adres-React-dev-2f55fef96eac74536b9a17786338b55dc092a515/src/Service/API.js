import Axios from "axios";
import { errorHandler } from "../utils";

const REFRESH_TOKEN_ENDPOINT = "";

const axiosInstance = Axios.create({
    baseURL: "",
});

axiosInstance.interceptors.request.use(
    (request) => {
        // const token = store.getState().session.token;
        const accessToken = localStorage.getItem("accessToken");
        if (accessToken) {
            request.headers["Authorization"] = `Bearer ${accessToken}`;
        }
        return request;
    },
    (error) => {
        return Promise.reject(error);
    }
);

axiosInstance.interceptors.response.use(
    (response) => response,
    async (error) => {
        const originalRequest = error.config;

        if (originalRequest.url === REFRESH_TOKEN_ENDPOINT) {
            localStorage.clear();
            window.location.href = "/";
            return Promise.reject(error);
        }

        if (error.response?.status === 401 && !originalRequest._retry) {
            originalRequest._retry = true;
            const refreshToken = localStorage.getItem("refreshToken");
            if (refreshToken) {
                try {
                    const response = await Axios.post("refresh-token-api", {
                        refreshToken,
                    });
                    const { accessToken, refreshToken: newRefreshToken } =
                        response.data;
                    localStorage.setItem("accessToken", accessToken);
                    localStorage.setItem("refreshToken", newRefreshToken);
                    axiosInstance.defaults.headers.common["Authorization"] =
                        `Bearer ${accessToken}`;
                    return axiosInstance(originalRequest);
                } catch (refreshError) {
                    localStorage.clear();
                    window.location.href = "/";
                    return Promise.reject(error);
                }
            } else {
                localStorage.clear();
                window.location.href = "/";
                return Promise.reject(error);
            }
        }
        return Promise.reject(error);
    }
);

export const makeRequest = async (method, endpoint, data = {}, params = {}) => {
    try {
        const config = {
            method,
            url: endpoint,
            data,
            params,
        };
        const response = await axiosInstance(config);
        return response.data;
    } catch (error) {
        const err = errorHandler;
        return err;
    }
};

export { makeRequest, axiosInstance };
