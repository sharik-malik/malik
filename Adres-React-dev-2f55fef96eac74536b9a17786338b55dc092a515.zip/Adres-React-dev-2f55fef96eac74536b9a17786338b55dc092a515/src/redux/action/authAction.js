import authSlice from "../slice/authSlice";
import { toast } from "react-toastify";
import { config } from "../../utils";
import axios from "../../helpers/axios";

export const authAction = authSlice.actions;

export const logout = () => {
    return async (dispatch) => {
        dispatch(authAction.logout());
    };
};

export const handleSiteLoader = (val) => {
    return async (dispatch) => {
        dispatch(authAction.handleSiteLoader(val));
    };
};

export const registerUser = (token, formData) => {
    return async (dispatch, getState) => {
        dispatch(authAction.handleSiteLoader(true));
        try {
            const res = await axios.post(
                `api-users/subdomain-registration/`,
                formData,
                config(token)
            );
            const { msg, status } = res.data;
            if (status === 200) {
                toast.success(msg);
            } else toast.error(msg);
            dispatch(authAction.handleSiteLoader(false));
            return res.data;
        } catch (err) {
            // errToast(err );
            dispatch(authAction.handleSiteLoader(false));
        }
    };
};
