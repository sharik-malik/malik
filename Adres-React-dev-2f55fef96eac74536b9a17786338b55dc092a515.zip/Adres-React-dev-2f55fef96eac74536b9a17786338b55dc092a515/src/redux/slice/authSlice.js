import { createSlice } from "@reduxjs/toolkit";

const initialState = {
    isAuthenticated: false,
    token: "",
    siteLoader: false,
};

export const authSlice = createSlice({
    name: "auth",
    initialState,
    reducers: {
        loadToken: (state, action) => {
            return {
                ...state,
                token: action.payload,
                isAuthenticated: true,
            };
        },
        logout: () => {
            return {
                ...initialState,
            };
        },
        handleSiteLoader: (state, action) => {
            return {
                ...state,
                siteLoader: action.payload,
            };
        },
        registerUser: () => {
            return {
                ...initialState,
            };
        },
    },
});

export default authSlice;
