import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import PrivateRoute from "./PrivateRoute";
import PublicRoute from "./PublicRoute";
import routes from "./Routes";
import PageNotFound from "../pages/PageNotFound";
import ScrollToTop from "../components/common/ScrollToTop";

const AppRouter = () => {
    return (
        <Router>
            <ScrollToTop>
                <Routes>
                    {/* Render Public Routes */}
                    {routes.publicRoutes.map(({ path, element, children }) => (
                        <Route
                            key={path}
                            path={path}
                            element={<PublicRoute element={element} />}
                        >
                            {children &&
                                children.map((childRoute) => (
                                    <Route
                                        key={childRoute.path}
                                        path={childRoute.path}
                                        element={childRoute.element}
                                    />
                                ))}
                        </Route>
                    ))}

                    {/* Render Private Routes */}
                    {routes.privateRoutes.map(({ path, element, children }) => (
                        <Route
                            key={path}
                            path={path}
                            element={<PrivateRoute element={element} />}
                        >
                            {children &&
                                children.map((childRoute) => (
                                    <Route
                                        key={childRoute.path}
                                        path={childRoute.path}
                                        element={childRoute.element}
                                    />
                                ))}
                        </Route>
                    ))}
                    <Route path={"*"} element={<PageNotFound />} />
                </Routes>
            </ScrollToTop>
        </Router>
    );
};

export default AppRouter;
