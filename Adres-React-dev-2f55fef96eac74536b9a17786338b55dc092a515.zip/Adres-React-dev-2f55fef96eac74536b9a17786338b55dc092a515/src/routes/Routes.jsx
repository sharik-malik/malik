import Home from "../pages/Home";
import SignIn from "../pages/SignIn";
import SignUp from "../pages/SignUp";

const routes = {
    publicRoutes: [
        {
            path: "/",
            element: <Home />,
        },
        {
            path: "/signin",
            element: <SignIn />,
        },
        {
            path: "/signup",
            element: <SignUp />,
        },
    ],
    privateRoutes: [
        {
            path: "/dashboard",
            element: <div>dashboard</div>,
        },
    ],
};

export default routes;
