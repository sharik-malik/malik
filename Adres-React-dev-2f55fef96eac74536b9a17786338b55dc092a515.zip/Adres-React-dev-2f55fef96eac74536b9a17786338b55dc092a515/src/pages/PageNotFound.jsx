import React from "react";

function PageNotFound() {
    return <div>Oops 404 not found</div>;
}

export default PageNotFound;
