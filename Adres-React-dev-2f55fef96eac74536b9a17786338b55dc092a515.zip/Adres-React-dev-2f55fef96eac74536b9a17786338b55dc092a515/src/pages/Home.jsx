import React from "react";
import Layout from "../components/common/layout/Index";
import { Helmet } from "react-helmet";

function Home() {
    return (
        <>
            <Helmet>
                <meta
                    name="keywords"
                    content="Bidhome-Adres, CRE, brokers, investment, commercial real estate, sales, auction"
                />
                <meta
                    name="description"
                    content="Bidhome-Adres brings buyers, sellers, and brokers together to efficiently market and close commercial real estate deals in online CRE auctions."
                />
                <title>Property Auction - Home Page</title>
            </Helmet>
            <Layout>
                <div>Home</div>
            </Layout>
            <></>
        </>
    );
}

export default Home;
