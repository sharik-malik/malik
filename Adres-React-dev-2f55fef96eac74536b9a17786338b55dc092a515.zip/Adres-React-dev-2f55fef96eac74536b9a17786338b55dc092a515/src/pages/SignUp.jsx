import React from "react";
import { Helmet } from "react-helmet";
import Layout from "../components/common/layout/Index";
import SignUpForm from "../components/signup/SignUpForm";

function SignUp() {
    return (
        <>
            <Helmet>
                <meta
                    name="keywords"
                    content="Bidhome-Adres, CRE, brokers, investment, commercial real estate, sales, auction"
                />
                <meta
                    name="description"
                    content="Bidhome-Adres brings buyers, sellers, and brokers together to efficiently market and close commercial real estate deals in online CRE auctions."
                />
                <title>Property Auction - Signup Page</title>
            </Helmet>
            <Layout>
                <SignUpForm />
            </Layout>
            <></>
        </>
    );
}

export default SignUp;
