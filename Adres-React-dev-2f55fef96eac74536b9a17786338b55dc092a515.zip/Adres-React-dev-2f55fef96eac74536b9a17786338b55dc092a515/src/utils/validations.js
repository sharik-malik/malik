import { emailRegExp } from "../helpers/index";
import * as Yup from "yup";

//signin
export const SignInValidationSchema = Yup.object().shape({
    email: Yup.string()
        .strict()
        .trim("The email cannot include leading and trailing spaces")
        .required("Email is required")
        .matches(emailRegExp, "Email is invalid"),
    password: Yup.string()
        .strict()
        .trim("The password cannot include leading and trailing spaces")
        .required("Password is required"),
});
