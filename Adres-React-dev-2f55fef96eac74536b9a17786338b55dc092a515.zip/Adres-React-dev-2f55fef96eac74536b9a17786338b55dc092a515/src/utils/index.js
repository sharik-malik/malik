import axios from "axios";
export const errorHandler = (error) => {
    const { request, response } = error;
    if (response) {
        const { message } = response.data;
        const status = response.status;
        return { msg: message, status };
    } else if (request) {
        if (axios.isCancel(error)) {
            return { msg: error.message, status: error.status };
        }
        return { msg: "server time out", status: 503 };
    } else {
        return { msg: "opps! something went wrong while setting up request" };
    }
};

export const config = (token) => {
    return {
        headers: {
            "Content-Type": "application/json",
            Authorization: `Token ${token}`,
        },
    };
};
