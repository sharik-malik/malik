import React, { useEffect, useState } from "react";
import {
    signupFormFields,
    emailRegExp,
    weakRegExp,
    goodRegExp,
    strongRegExp,
} from "../../helpers/index";
import { useForm } from "react-hook-form";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import Button from "../common/Button";
import Input from "../common/form/Input";
import PasswordInput from "../common/form/PasswordInput";
import "react-phone-number-input/style.css";
import MobileInput from "../common/form/MobileInput";
import { registerUser } from "../../redux/action/authAction";
import { useDispatch, useSelector } from "react-redux";

const SignUpForm = () => {
    const {
        register,
        handleSubmit,
        formState: { errors },
        watch,
        getValues,
        setFocus,
        setValue,
        control,
    } = useForm();

    const [state, setState] = useState({
        step: 1,
        timer: 60,
        pswdStrength: "",
        currentField: "",
        showPwd: {
            password: false,
            confirmPassword: false,
        },
    });

    const dispatch = useDispatch();
    const { step, timer, pswdStrength, currentField, showPwd } = state;
    const signUpData = JSON.parse(localStorage.getItem("signUpData"));
    const password = watch("password");
    const confirmPassword = watch("confirmPassword");

    useEffect(() => {
        let countdown = null;

        if (step === 2 && timer > 0) {
            countdown = setInterval(() => {
                setState((prev) => ({
                    ...prev,
                    timer: prev.timer - 1,
                }));
            }, 1000);
        } else if (timer === 0) {
            clearInterval(countdown);
        }

        return () => {
            if (countdown) clearInterval(countdown);
        };
    }, [step, timer]);

    useEffect(() => {
        const pswd = currentField === "password" ? password : confirmPassword;
        if (pswd) {
            let strength = "";

            if (strongRegExp.test(pswd)) strength = "Strong";
            else if (goodRegExp.test(pswd)) strength = "Good";
            else if (weakRegExp.test(pswd)) strength = "Weak";
            else strength = "Weak";

            setState((prev) => ({ ...prev, pswdStrength: strength }));
        }
    }, [password, confirmPassword, currentField]);

    const handleOtpInput = (index, value) => {
        const otpFields = ["otpDigit1", "otpDigit2", "otpDigit3", "otpDigit4"];

        setValue(otpFields[index], value);

        if (value.length === 1 && index < 3) {
            setFocus(otpFields[index + 1]);
        } else if (value.length === 0 && index > 0) {
            setFocus(otpFields[index - 1]);
        }
        const updatedOtpValues = otpFields.map((field) => getValues(field));

        if (updatedOtpValues.every((digit) => digit && digit.length === 1)) {
            const otp = updatedOtpValues.join("");
            if (otp === "1234") {
                setState((prev) => ({
                    ...prev,
                    step: 3,
                }));
                toast.success("OTP Verified Successfully!");
            } else {
                toast.error("Invalid OTP");
            }
        }
    };

    const renderHeader = (step) => {
        switch (step) {
            case 1:
                return (
                    <h4 className="display-4 mb-4">
                        Create Your Account
                        <span>Let’s begin by verifying your phone number.</span>
                    </h4>
                );

            case 2:
                return (
                    <>
                        <h4 className="display-4 mb-4">
                            Enter Verification Code
                            <span>
                                We’ve sent a code to {signUpData?.phoneNumber}.
                                Enter it below to verify your number.
                            </span>
                        </h4>
                    </>
                );
            case 3:
                return (
                    <>
                        <h4 className="display-4 mb-4">
                            Complete Your Profile
                            <span>
                                Just a few details to set up your account,
                            </span>
                        </h4>
                    </>
                );
            case 4:
                return (
                    <>
                        <h4 className="display-4 mb-4">
                            Add Payment Details
                            <span>
                                Add a card for deposits to participate in
                                auctions. The deposit amount AED 1500 will be
                                held for now to place this bid.
                            </span>
                        </h4>
                        <div className="card-list">
                            <div className="col">
                                <div className="bdr">
                                    <img src="img/visa-icon.svg" alt="" />
                                </div>
                            </div>
                            <div className="col">
                                <div className="bdr">
                                    <img src="img/mastercard-icon.svg" alt="" />
                                </div>
                            </div>
                            <div className="col">
                                <div className="bdr">
                                    <img src="img/paypal-icon.svg" alt="" />
                                </div>
                            </div>
                        </div>

                        <div className="mb-4">
                            <label
                                htmlFor="validationServer01"
                                className="form-label"
                            >
                                Card Number
                            </label>
                            <input
                                type="text"
                                className="form-control is-valid"
                                placeholder="3356 1424 6557 9999"
                                id="validationServer01"
                                // value="Mark"
                                // required
                            />
                        </div>
                        <div className="row">
                            <div className="col-md-6">
                                <div className="mb-4">
                                    <label
                                        htmlFor="name"
                                        className="form-label"
                                    >
                                        Exp. Date
                                    </label>
                                    <input
                                        type="text"
                                        className="form-control"
                                        placeholder="00/00"
                                    />
                                </div>
                            </div>
                            <div className="col-md-6">
                                <div className="mb-4">
                                    <label
                                        htmlFor="name"
                                        className="form-label"
                                    >
                                        CVV
                                    </label>
                                    <input
                                        type="text"
                                        className="form-control"
                                        placeholder="000"
                                    />
                                </div>
                            </div>
                        </div>
                        <div className="mb-4">
                            <label htmlFor="name" className="form-label">
                                Card Holder Name
                            </label>
                            <input
                                type="text"
                                className="form-control"
                                placeholder="Enter your password"
                            />
                        </div>
                        <div className="mb-4 check">
                            <input
                                type="checkbox"
                                className="css-checkbox"
                                id="card-info"
                                name="card-info"
                            />
                            <label htmlFor="card-info" className="css-label">
                                Save this card information
                            </label>
                        </div>
                        <div className="mb-4">
                            <a
                                href="void:{0}"
                                className="btn btn-primary btn-lg btn-full"
                            >
                                Save & Contiune
                            </a>
                        </div>
                        <div className="text-center">
                            <button
                                className="skip-text"
                                onClick={(e) => {
                                    e.preventDefault();
                                    setState((prev) => ({
                                        ...prev,
                                        step: 5,
                                    }));
                                }}
                            >
                                Skip for Now
                            </button>
                        </div>
                    </>
                );
            case 5:
                return (
                    <>
                        <div className="payment-check">
                            <img
                                src="img/payment-check.svg"
                                alt="Payment Check"
                            />
                        </div>
                        <h4 className="display-4 mb-4">
                            Your Account is Ready!
                            <span>
                                You’re all set up! To start bidding, please
                                verify your account. You can do this now or skip
                                and verify later from your profile settings.
                            </span>
                        </h4>
                        <div className="mb-4">
                            <a
                                href="void:{0}"
                                className="btn btn-primary btn-lg btn-full"
                            >
                                Verify Account Now
                            </a>
                        </div>
                        <div className="text-center">
                            <a href="void:{0}" className="skip-text">
                                Skip for Now
                            </a>
                        </div>
                    </>
                );
            default:
                <></>;
        }
    };
    const validationRules = (item) => ({
        required: "This field is required",
        ...(item.id === 1 && {
            pattern: {
                value: /^[0-9]{10,15}$/,
                message: "Enter a valid phone number",
            },
        }),
        ...(item.id === 4 && {
            minLength: {
                value: 5,
                message: "Minimum length is 5 characters",
            },
            maxLength: {
                value: 30,
                message: "Maximum length is 30 characters",
            },
        }),
        ...(item.id === 5 && {
            pattern: {
                value: emailRegExp,
                message: "Please enter a valid email address",
            },
        }),
        ...(item.id === 6 && {
            minLength: {
                value: 6,
                message: "Password must be at least 6 characters",
            },
            maxLength: {
                value: 12,
                message: "Maximum length is 12 characters",
            },
        }),
        ...(item.id === 7 && {
            validate: (value) =>
                value === getValues("password") || "Passwords do not match",
        }),
    });

    const renderInputField = (item) => (
        <div className="mb-4" key={item.id}>
            {item.id === 1 ? (
                <>
                    <MobileInput
                        control={control}
                        name={item.name}
                        placeholder={item.placeholder}
                        defaultCountry="AE"
                        international
                        countryCallingCodeEditable={false}
                        className={item.className}
                        label={item.label}
                        labelClassname={item.labelClassname}
                        errors={errors}
                        rules={{
                            required: "Phone number is required",
                        }}
                    />
                </>
            ) : item.type === "password" ? (
                <PasswordInput
                    id={item.id}
                    className={item.classname}
                    placeholder={item.placeholder}
                    label={item.label}
                    labelClassname={item.labelClassname}
                    register={register}
                    errors={errors}
                    {...register(item.name, validationRules(item))}
                    handleShowPwd={() => {
                        setState((prev) => ({
                            ...prev,
                            showPwd: {
                                ...prev.showPwd,
                                [item.name]: !prev.showPwd[item.name],
                            },
                        }));
                    }}
                    showPwd={showPwd[item.name]}
                    onFocus={() =>
                        setState((prev) => ({
                            ...prev,
                            currentField: item.name,
                        }))
                    }
                    onBlur={() =>
                        setState((prev) => ({
                            ...prev,
                            currentField: "",
                        }))
                    }
                />
            ) : (
                <Input
                    type={item.type}
                    id={item.id}
                    className={item.classname}
                    placeholder={item.placeholder}
                    label={item.label}
                    labelClassname={item.labelClassname}
                    register={register}
                    errors={errors}
                    {...register(item.name, validationRules(item))}
                />
            )}
            {(item.id === 6 || item.id === 7) &&
                currentField === item.name &&
                renderPasswordStrengthMeter()}
        </div>
    );

    const renderOtpInput = (item) => (
        <div className="mb-4" key={item.id}>
            <div className="ph-list">
                {item?.inputField?.map((field, index) => (
                    <div className="col" key={index}>
                        <input
                            type="text"
                            className={item.classname}
                            {...register(field.name, {
                                required: "This field is required",
                            })}
                            onChange={(e) =>
                                handleOtpInput(index, e.target.value)
                            }
                        />
                    </div>
                ))}
            </div>
            {Object.keys(errors).some((key) => key.includes("otpDigit")) && (
                <div className="required font14">
                    All OTP fields are required.
                </div>
            )}
            {/* <div className="required font14">
                    Wrong code. You have {3 - wrongAttempts} attempts left.
                </div> */}
        </div>
    );

    const renderPasswordStrengthMeter = () =>
        pswdStrength && (
            <div className="password-strength-group mt-3" data-strength="">
                <div
                    id="password-strength-meter"
                    className="password-strength-meter"
                >
                    <div className="meter-block"></div>
                    <div className="meter-block"></div>
                    <div className="meter-block"></div>
                </div>
                {pswdStrength === "Weak"
                    ? "Weak Password"
                    : pswdStrength === "Good"
                      ? "Good Password"
                      : pswdStrength === "Strong" && "Strong Password"}

                {/* <div className="password-strength-message">
                    <div className="message-item week-text">Weak Password</div>

                    <div className="message-item good-text">Good Password</div>

                    <div className="message-item strong-text">
                        Strong Password
                    </div>
                </div> */}
            </div>
        );

    const renderFormField = (item) => {
        switch (item.option_type_display) {
            case "Input":
                return renderInputField(item);
            case "OtpInput":
                return renderOtpInput(item);
            default:
                return null;
        }
    };

    const onSubmit = async (data) => {
        if (step === 1) {
            setState((prev) => ({
                ...prev,
                step: 2,
            }));
            toast.success("OTP Sent Successfully!");
        } else if (step === 2) {
            setState((prev) => ({
                ...prev,
                timer: 60,
            }));
            toast.success("Resending OTP successfully");
        } else if (step === 3) {
            const { phoneNo, name, email, password } = data;

            const userData = {
                domain_id: 3,
                described_by: "1",
                first_name: name,
                last_name: "",
                email: email,
                password: password,
                phone_no: phoneNo,
                agree_term: 1,
            };

            dispatch(
                registerUser(process.env.REACT_APP_STATIC_TOKEN, userData)
            );
            setState((prev) => ({
                ...prev,
                step: 4,
            }));
        }
    };

    return (
        <section className="login-wrap">
            <div className="container py-5">
                <div className="row g-5 align-items-center">
                    <div
                        className="offset-lg-3 col-lg-6 wow fadeInUp"
                        data-wow-delay="0.5s"
                    >
                        <form onSubmit={handleSubmit(onSubmit)}>
                            <div
                                className={
                                    step === 5 ? "payment-box" : "login-box"
                                }
                            >
                                {renderHeader(step)}
                                {signupFormFields
                                    ?.filter((item) => item.step === step)
                                    .map((item) => renderFormField(item))}
                                {(step === 1 || step === 2 || step === 3) && (
                                    <div className="clear">
                                        <Button
                                            className={
                                                "btn btn-primary btn-full btn-lg"
                                            }
                                            type={
                                                step === 2 ? "button" : "submit"
                                            }
                                            disabled={step === 2 && timer > 0}
                                            onClick={() => {
                                                if (step === 2) {
                                                    setState((prev) => ({
                                                        ...prev,
                                                        timer: 60,
                                                    }));
                                                    toast.success(
                                                        "Resending OTP successfully"
                                                    );
                                                }
                                            }}
                                            label={
                                                step === 1
                                                    ? "Send Code"
                                                    : step === 2
                                                      ? timer > 0
                                                          ? timer >= 60
                                                              ? `Resend Code in ${Math.floor(
                                                                    timer / 60
                                                                )}:${timer % 60 < 10 ? "0" : ""}${
                                                                    timer % 60
                                                                }`
                                                              : `Resend Code in ${timer}s`
                                                          : "Resend Code"
                                                      : step === 3 && "Next"
                                            }
                                        />
                                    </div>
                                )}
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    );
};
export default SignUpForm;
