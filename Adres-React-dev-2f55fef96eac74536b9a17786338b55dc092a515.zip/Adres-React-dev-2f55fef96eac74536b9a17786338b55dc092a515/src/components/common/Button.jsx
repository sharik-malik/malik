import React from "react";

export default function Button({
    label,
    onClick,
    className,
    labelClassName,
    ...rest
}) {
    return (
        <button onClick={onClick} className={`${className}`} {...rest}>
            <span className={`${labelClassName}`}>{label}</span>
        </button>
    );
}
