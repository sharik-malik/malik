import React from "react";
import Footer from "./Footer";
import Header from "./Header";
import { ToastContainer, Slide } from "react-toastify";

export default function Layout({ children }) {
    return (
        <>
            <ToastContainer
                theme="colored"
                position="top-right"
                transition={Slide}
                autoClose={5000}
                hideProgressBar
                newestOnTop
                closeOnClick
                rtl={false}
                pauseOnFocusLoss={false}
                draggable
                pauseOnHover={false}
            />
            <Header />
            {children}
            <Footer />
        </>
    );
}
