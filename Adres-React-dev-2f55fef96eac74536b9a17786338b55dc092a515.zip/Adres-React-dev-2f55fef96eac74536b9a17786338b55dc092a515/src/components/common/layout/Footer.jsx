import React from "react";

const Footer = () => (
    <footer className="footer container-fluid wow fadeIn" data-wow-delay="0.1s">
        <div className="container">
            <div className="row g-5">
                <div
                    className="col-lg-5 col-md-6 wow fadeInUp"
                    data-wow-delay="1s"
                >
                    <h2 className="mb-4">
                        <img src="img/logo-f.svg" alt="Property Auction Logo" />
                    </h2>
                    <p className="mb-4">
                        Our trusted platform for seamless property <br />
                        auctions. Buy, sell, and bid with confidence.
                    </p>
                    <div className="social-links d-flex">
                        <a className="me-4" href="void:{0}">
                            <i className="fab fa-facebook-f"></i>
                        </a>
                        <a className="me-4" href="void:{0}">
                            <i className="fa-brands fa-x-twitter"></i>
                        </a>
                        <a className="me-4" href="void:{0}">
                            <i className="fa-brands fa-instagram"></i>
                        </a>
                    </div>
                </div>

                <div
                    className="col-lg-2 col-md-6 wow fadeInUp"
                    data-wow-delay="1.3s"
                >
                    <a className="btn-link" href="void:{0}">
                        About Us
                    </a>
                    <a className="btn-link" href="void:{0}">
                        Contact Us
                    </a>
                    <a className="btn-link" href="void:{0}">
                        Clients
                    </a>
                    <a className="btn-link" href="void:{0}">
                        Terms & Conditions
                    </a>
                </div>
                <div
                    className="col-lg-2 col-md-6 wow fadeInUp"
                    data-wow-delay="1.7s"
                >
                    <a className="btn-link" href="void:{0}">
                        Privacy Policy
                    </a>
                    <a className="btn-link" href="void:{0}">
                        FAQs
                    </a>
                    <a className="btn-link" href="void:{0}">
                        Blog
                    </a>
                </div>
                <div
                    className="col-lg-3 col-md-6 wow fadeInUp text-end"
                    data-wow-delay="1.9s"
                >
                    <a href="void:{0}" className="app-link mb-3">
                        <img src="img/appstore-icon.svg" alt="" />
                    </a>
                    <a href="void:{0}" className="app-link">
                        <img src="img/googleplay-icon.svg" alt="" />
                    </a>
                </div>
            </div>
        </div>

        <div className="container">
            <div className="col-lg-12">
                <div className="copyright">
                    © Copyright 2024 HandyHub. All rights reserved.
                </div>
            </div>
        </div>
    </footer>
);

export default Footer;
