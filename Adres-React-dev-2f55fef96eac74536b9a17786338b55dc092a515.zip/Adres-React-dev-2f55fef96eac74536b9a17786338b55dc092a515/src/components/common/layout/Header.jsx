import React from "react";
import { useNavigate } from "react-router-dom";
import Button from "../Button";

const Header = () => {
    const navigate = useNavigate();

    const handleLink = () => {
        navigate("/signin");
    };
    return (
        <header className="header position-relative p-0">
            <nav className="navbar navbar-expand-lg navbar-light">
                <div className="container">
                    <a href="index.html" className="navbar-brand p-0">
                        <img src="img/logo.svg" alt="Property Auction Logo" />
                    </a>
                    <button
                        className="navbar-toggler"
                        type="button"
                        data-bs-toggle="collapse"
                        data-bs-target="#navbarCollapse"
                    >
                        <span className="fa fa-bars"></span>
                    </button>
                    <div
                        className="collapse navbar-collapse ms-4"
                        id="navbarCollapse"
                    >
                        <div className="navbar-nav py-0">
                            <a
                                href="/discover"
                                className="nav-item nav-link active"
                            >
                                Discover
                            </a>
                            <a
                                href="my-bids.html"
                                className="nav-item nav-link"
                            >
                                My Bids
                            </a>
                            <a href="events.html" className="nav-item nav-link">
                                Events
                            </a>
                            <a
                                href="projects.html"
                                className="nav-item nav-link"
                            >
                                Projects
                            </a>
                            <a
                                href="login.html"
                                className="btn-login nav-link btn btn-primary py-2 px-4 ms-lg-4"
                            >
                                Login
                            </a>
                        </div>
                    </div>
                    <Button
                        label="Login"
                        type="submit"
                        className="btn btn-primary btn-sm"
                        onClick={handleLink}
                    />
                </div>
            </nav>
        </header>
    );
};

export default Header;
