import React from "react";
import Select from "react-select";
const ReactSelect = ({
    options,
    onChange,
    value,
    isMulti = false,
    placeholder = "",
    isSearchable = false,
    isDisabled = false,
    className = "",
}) => {
    return (
        <Select
            options={options}
            onChange={onChange}
            value={value}
            isMulti={isMulti}
            placeholder={placeholder}
            isSearchable={isSearchable}
            isDisabled={isDisabled}
            className={className}
            components={{
                IndicatorSeparator: () => null,
            }}
        />
    );
};
export default ReactSelect;
