import React from "react";

export default function PasswordInput({
    id,
    label,
    labelClassname,
    name,
    classname,
    register,
    errors,
    handleShowPwd,
    showPwd,
    ...rest
}) {
    return (
        <>
            {label && (
                <label htmlFor={id} className={labelClassname}>
                    {label}
                </label>
            )}
            <div className="position-relative">
                <button
                    type="button"
                    className="showpwd"
                    onClick={() => {
                        handleShowPwd();
                    }}
                >
                    <img
                        src="img/eye-icon.svg"
                        alt="Toggle Password Visibility"
                    />
                </button>
                <input
                    className={classname}
                    type={showPwd ? "text" : "password"}
                    {...register(name)}
                    {...rest}
                />
            </div>

            {errors?.[name] && (
                <span className="text-danger">{errors[name].message}</span>
            )}
        </>
    );
}
