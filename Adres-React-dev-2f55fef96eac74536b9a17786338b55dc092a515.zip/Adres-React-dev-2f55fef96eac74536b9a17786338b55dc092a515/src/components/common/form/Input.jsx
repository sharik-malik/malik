import React from "react";

export default function Input({
    id,
    label,
    labelClassname,
    name,
    classname,
    register,
    errors,
    ...rest
}) {
    return (
        <>
            {label && (
                <label htmlFor={id} className={labelClassname}>
                    {label}
                </label>
            )}

            <input className={classname} {...register(name)} {...rest} />

            {errors?.[name] && (
                <span className="text-danger">{errors[name].message}</span>
            )}
        </>
    );
}
