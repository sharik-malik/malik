import React from "react";
import { Controller } from "react-hook-form";
import "react-phone-number-input/style.css";
import PhoneInput, { isValidPhoneNumber } from "react-phone-number-input";

const MobileInput = ({
    control,
    label,
    id,
    className,
    labelClassname,
    name,
    errors,
    rules,
    ...rest
}) => {
    return (
        <>
            {label && (
                <label htmlFor={id} className={labelClassname}>
                    {label}
                </label>
            )}
            <Controller
                control={control}
                name={name}
                rules={{
                    ...rules,
                    validate: (value) =>
                        value && isValidPhoneNumber(value)
                            ? true
                            : "Invalid phone number",
                }}
                render={({ field: { onChange, value } }) => (
                    <PhoneInput
                        className={className}
                        value={value}
                        onChange={(e) => {
                            onChange(e);
                        }}
                        {...rest}
                    />
                )}
            />
            {errors?.[name] && (
                <span className="text-danger">{errors[name].message}</span>
            )}
        </>
    );
};

export default MobileInput;
