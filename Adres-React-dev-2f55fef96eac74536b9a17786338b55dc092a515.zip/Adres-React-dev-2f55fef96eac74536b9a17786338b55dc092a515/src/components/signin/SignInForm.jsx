import React, { useState } from "react";
import { Link } from "react-router-dom";
import { useForm } from "react-hook-form";
import Input from "../common/form/Input";
import PasswordInput from "../common/form/PasswordInput";
import Button from "../common/Button";
import { yupResolver } from "@hookform/resolvers/yup";
import { SignInValidationSchema } from "../../utils/validations";
import "react-toastify/dist/ReactToastify.css";
import Checkbox from "../common/form/Checkbox";

const SignInForm = () => {
    const {
        register,
        handleSubmit,
        control,
        formState: { errors },
    } = useForm({
        resolver: yupResolver(SignInValidationSchema),
    });

    const [state, setState] = useState({
        showPwd: false,
    });
    const { showPwd } = state;

    const onSubmit = (data) => {
        console.log(data);
    };

    return (
        <section className="login-wrap">
            <div className="container py-5">
                <div className="row g-5 align-items-center">
                    <div
                        className="offset-lg-3 col-lg-6 wow fadeInUp"
                        data-wow-delay="0.5s"
                    >
                        <div className="login-box">
                            <form onSubmit={handleSubmit(onSubmit)}>
                                <h4 className="display-4 mb-4">
                                    Login to Your Account
                                    <span>
                                        Welcome back, you’ve been missed!
                                    </span>
                                </h4>

                                <div className="mb-4">
                                    <Input
                                        type="text"
                                        id="email"
                                        className="form-control"
                                        placeholder="Enter your email"
                                        label="Email"
                                        labelClassname="form-label"
                                        register={register}
                                        errors={errors}
                                        {...register("email")}
                                    />
                                </div>
                                <div className="mb-4">
                                    <PasswordInput
                                        id="password"
                                        className="form-control"
                                        placeholder="Enter your password"
                                        label="Password"
                                        labelClassname="form-label"
                                        register={register}
                                        errors={errors}
                                        {...register("password")}
                                        handleShowPwd={() =>
                                            setState((prev) => ({
                                                ...prev,
                                                showPwd: !showPwd,
                                            }))
                                        }
                                        showPwd={showPwd}
                                    />
                                </div>
                                <div className="mb-4">
                                    <Button
                                        className={
                                            "btn btn-primary btn-full btn-lg"
                                        }
                                        label={"Login"}
                                        type="submit"
                                    />
                                </div>

                                <div className="mb-4 login-check">
                                    <div className="check">
                                        <Checkbox
                                            type="checkbox"
                                            name="remember"
                                            control={control}
                                            id="remember"
                                            className="css-checkbox"
                                            labelClassName="css-label"
                                            label="Remember Me"
                                            rules={{
                                                required:
                                                    "This field is required",
                                            }}
                                        />
                                    </div>
                                    <div className="forgot">
                                        <a href="void:{0}">Forgot Password ?</a>
                                    </div>
                                </div>
                            </form>

                            <div className="mb-4 seperate">
                                <span>or</span>
                            </div>
                            <div className="mb-4">
                                <a
                                    href="void:{0}"
                                    className="btn btn-white btn-full"
                                >
                                    <img
                                        src="img/thumb-icon.svg"
                                        alt="thumb icon"
                                    />
                                    Login with UAE PASS
                                </a>
                            </div>
                            <div className="mb-4 play-btns">
                                <a href="void:{0}" className="btn btn-white">
                                    <img src="img/google-icon.svg" alt="" />
                                </a>
                                <button className="btn btn-white">
                                    <img src="img/apple-icon.svg" alt="" />
                                </button>
                            </div>
                            <div className="text-center">
                                <Link to="/signup">
                                    Don’t Have an Account?{" "}
                                    <strong>Signup</strong>
                                </Link>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default SignInForm;
