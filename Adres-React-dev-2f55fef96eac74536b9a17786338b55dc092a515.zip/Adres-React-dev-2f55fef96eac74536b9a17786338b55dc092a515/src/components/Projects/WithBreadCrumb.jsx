import React, { Fragment } from "react";

const WithBreadCrumb = (WrappedComponent, condition) => {
    return (props) => {
        return (
            <Fragment>
                <div className="breadcrumb-wrap">
                    <div className="container">
                        <div className="row">
                            <div className="col-lg-12">
                                <nav>
                                    <ol className="breadcrumb">
                                        <li className="breadcrumb-item">
                                            <a href="#">Home</a>
                                        </li>
                                        <li className="breadcrumb-item">
                                            <a href="#">Projects</a>
                                        </li>
                                        <li className="breadcrumb-item">
                                            <a href="#">ARC Towers</a>
                                        </li>
                                        <li
                                            className="breadcrumb-item active"
                                            aria-current="page"
                                        >
                                            Properties Under ARC
                                        </li>
                                    </ol>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
                <WrappedComponent {...props} />
            </Fragment>
        );
    };
};
export default WithBreadCrumb;
