export const emailRegExp =
    // eslint-disable-next-line
    /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

export const weakRegExp = /^([a-zA-Z0-9]{6,})$/;

export const goodRegExp = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{8,}$/;

export const strongRegExp =
    /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{12,}$/;

export const signupFormFields = [
    {
        id: 1,
        option_type_display: "Input",
        step: 1,
        label: "Phone Number",
        labelClassname: "form-label",
        name: "phoneNo",
        classname: "form-control",
        placeholder: "Phone Number",
        type: "text",
    },
    {
        id: 2,
        option_type_display: "Dropdown",
        step: 1,
        code: [
            {
                id: 1,
                code_text: "+91",
            },
            {
                id: 2,
                code_text: "+990",
            },
        ],
    },
    {
        id: 3,
        option_type_display: "OtpInput",
        step: 2,
        inputField: [
            { name: "otpDigit1" },
            { name: "otpDigit2" },
            { name: "otpDigit3" },
            { name: "otpDigit4" },
        ],
        classname: "form-control",
        type: "text",
    },
    {
        id: 4,
        option_type_display: "Input",
        step: 3,
        label: "Full Name",
        labelClassname: "form-label",
        name: "name",
        classname: "form-control",
        placeholder: "Enter your full name",
        type: "text",
    },
    {
        id: 5,
        option_type_display: "Input",
        step: 3,
        label: "Email",
        labelClassname: "form-label",
        name: "email",
        classname: "form-control",
        placeholder: "Enter your email",
        type: "email",
    },
    {
        id: 6,
        option_type_display: "Input",
        step: 3,
        label: "Password",
        labelClassname: "form-label",
        name: "password",
        classname: "form-control",
        type: "password",
    },
    {
        id: 7,
        option_type_display: "Input",
        step: 3,
        label: "Confirm Password",
        labelClassname: "form-label",
        name: "confirmPassword",
        classname: "form-control",
        type: "password",
    },
];
